import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Signup Endpoint
app.post("/make-server-2c9c9f09/signup", async (c) => {
  try {
    let { email, password, name } = await c.req.json();
    
    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }

    email = email.trim().toLowerCase();

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      email_confirm: true
    });

    if (error) {
      console.error("Signup error:", error);
      
      // If user already exists, try to update them to ensure they are confirmed and have the correct password
      // This is a "fix" for the prototype environment where email confirmation might be tricky
      if (error.message.includes("already registered") || error.status === 422) {
        // Find user by email - fetch more users to be safe
        const { data: { users }, error: listError } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 });
        if (listError) {
           return c.json({ error: listError.message }, 400);
        }
        
        const existingUser = users.find(u => u.email?.toLowerCase() === email);
        if (existingUser) {
          const { data: updateData, error: updateError } = await supabase.auth.admin.updateUserById(
            existingUser.id,
            { 
              password: password,
              email_confirm: true,
              user_metadata: { name }
            }
          );
          
          if (updateError) {
             return c.json({ error: updateError.message }, 400);
          }
          
          return c.json(updateData);
        }
      }

      return c.json({ error: error.message }, 400);
    }

    return c.json(data);
  } catch (err) {
    console.error("Server error during signup:", err);
    return c.json({ error: "Internal server error" }, 500);
  }
});

// Health check endpoint
app.get("/make-server-2c9c9f09/health", (c) => {
  return c.json({ status: "ok" });
});

// --- Mood Routes ---

app.post("/make-server-2c9c9f09/moods", async (c) => {
  try {
    const { userId, entry } = await c.req.json();
    if (!userId || !entry) return c.json({ error: "Missing userId or entry" }, 400);

    const newEntry = {
      ...entry,
      id: crypto.randomUUID(),
      userId,
      timestamp: new Date().toISOString(),
    };
    
    const key = `mood_history:${userId}`;
    const existing = await kv.get(key) || [];
    const history = Array.isArray(existing) ? existing : [];
    
    const updated = [newEntry, ...history];
    await kv.set(key, updated);
    
    return c.json(newEntry);
  } catch (err: any) {
    console.error("Error adding mood:", err);
    return c.json({ error: err.message }, 500);
  }
});

app.get("/make-server-2c9c9f09/moods/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const key = `mood_history:${userId}`;
    const data = await kv.get(key);
    return c.json(Array.isArray(data) ? data : []);
  } catch (err: any) {
    console.error("Error fetching moods:", err);
    return c.json({ error: err.message }, 500);
  }
});

// --- Vent Routes ---

app.post("/make-server-2c9c9f09/vent", async (c) => {
  try {
    const { userId, content, isAnonymous } = await c.req.json();
    if (!userId || !content) return c.json({ error: "Missing userId or content" }, 400);

    const id = crypto.randomUUID();
    const timestamp = new Date().toISOString();
    const newPost = {
      id,
      userId: isAnonymous ? 'anonymous' : userId,
      content,
      reactions: {},
      timestamp,
      isAnonymous,
    };
    
    const key = `vent:${timestamp}:${id}`;
    await kv.set(key, newPost);
    return c.json(newPost);
  } catch (err: any) {
    console.error("Error adding vent post:", err);
    return c.json({ error: err.message }, 500);
  }
});

app.get("/make-server-2c9c9f09/vent", async (c) => {
  try {
    const posts = await kv.getByPrefix('vent:');
    const sorted = posts.sort((a: any, b: any) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    return c.json(sorted);
  } catch (err: any) {
    console.error("Error fetching vent posts:", err);
    return c.json({ error: err.message }, 500);
  }
});

// --- Trusted Contact Routes ---

app.post("/make-server-2c9c9f09/contacts", async (c) => {
  try {
    const { userId, contact } = await c.req.json();
    if (!userId || !contact) return c.json({ error: "Missing userId or contact" }, 400);

    const newContact = {
      ...contact,
      id: crypto.randomUUID(),
    };
    
    const key = `contacts:${userId}`;
    const existing = await kv.get(key) || [];
    const contacts = Array.isArray(existing) ? existing : [];
    
    const updated = [...contacts, newContact];
    await kv.set(key, updated);
    return c.json(newContact);
  } catch (err: any) {
    console.error("Error adding contact:", err);
    return c.json({ error: err.message }, 500);
  }
});

app.get("/make-server-2c9c9f09/contacts/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const key = `contacts:${userId}`;
    const data = await kv.get(key);
    return c.json(Array.isArray(data) ? data : []);
  } catch (err: any) {
    console.error("Error fetching contacts:", err);
    return c.json({ error: err.message }, 500);
  }
});

Deno.serve(app.fetch);