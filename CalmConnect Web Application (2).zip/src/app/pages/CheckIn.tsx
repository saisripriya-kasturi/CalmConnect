
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { addMoodEntry } from '../services/store';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Label } from '../components/ui/label';
import { Smile, Frown, Meh, Angry, Battery, Zap, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

const moods = [
  { label: 'Happy', icon: Smile, color: 'bg-yellow-100 text-yellow-600 border-yellow-200' },
  { label: 'Excited', icon: Zap, color: 'bg-orange-100 text-orange-600 border-orange-200' },
  { label: 'Tired', icon: Battery, color: 'bg-purple-100 text-purple-600 border-purple-200' },
  { label: 'Anxious', icon: Meh, color: 'bg-blue-100 text-blue-600 border-blue-200' },
  { label: 'Sad', icon: Frown, color: 'bg-gray-100 text-gray-600 border-gray-200' },
  { label: 'Angry', icon: Angry, color: 'bg-red-100 text-red-600 border-red-200' },
];

const suggestions: Record<string, string[]> = {
  'Happy': [
    "Share your joy with a friend!",
    "Write down 3 things you're grateful for.",
    "Take a moment to savor this feeling."
  ],
  'Excited': [
    "Channel this energy into a creative project.",
    "Plan your next big goal.",
    "Go for a run or dance to your favorite song."
  ],
  'Tired': [
    "Take a 20-minute power nap.",
    "Drink a glass of water.",
    "Listen to a calming guided meditation."
  ],
  'Anxious': [
    "Try the 4-7-8 breathing technique.",
    "Write down your worries to clear your head.",
    "Ground yourself: Name 5 things you can see."
  ],
  'Sad': [
    "It's okay not to be okay. Allow yourself to feel.",
    "Reach out to a trusted friend.",
    "Watch your favorite comfort movie."
  ],
  'Angry': [
    "Step away and take 10 deep breaths.",
    "Squeeze a stress ball or pillow.",
    "Go for a brisk walk to release tension."
  ]
};

export const CheckIn = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [reflection, setReflection] = useState('');
  const [loading, setLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const handleSubmit = async () => {
    if (!selectedMood || !user) return;
    
    setLoading(true);
    try {
      await addMoodEntry(user.id, {
        mood: selectedMood as any,
        reflection
      });
      setShowSuggestions(true);
      toast.success('Check-in saved');
    } catch (error) {
      console.error(error);
      toast.error('Failed to save check-in');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <AnimatePresence mode="wait">
        {!showSuggestions ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-center">How are you feeling right now?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-8">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {moods.map((m) => {
                    const Icon = m.icon;
                    const isSelected = selectedMood === m.label;
                    return (
                      <button
                        key={m.label}
                        onClick={() => setSelectedMood(m.label)}
                        className={`
                          p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all duration-200
                          ${isSelected ? m.color + ' ring-2 ring-offset-2 ring-indigo-500' : 'bg-white border-gray-100 hover:border-gray-300 text-gray-500 hover:bg-gray-50'}
                        `}
                      >
                        <Icon size={32} />
                        <span className="font-medium">{m.label}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="space-y-3">
                  <Label htmlFor="reflection">Why do you feel this way? (Optional)</Label>
                  <textarea
                    id="reflection"
                    rows={4}
                    className="w-full rounded-lg border border-gray-200 p-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="I'm feeling this way because..."
                    value={reflection}
                    onChange={(e) => setReflection(e.target.value)}
                  />
                </div>

                <Button 
                  className="w-full" 
                  size="lg" 
                  disabled={!selectedMood || loading}
                  onClick={handleSubmit}
                >
                  {loading ? 'Saving...' : 'Save Check-in'}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            key="suggestions"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6"
          >
             <div className="text-center space-y-2">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600 mb-2">
                  <CheckCircle size={32} />
                </div>
                <h2 className="text-2xl font-bold text-gray-900">Thanks for checking in!</h2>
                <p className="text-gray-500">Here are some suggestions for you based on your mood.</p>
             </div>

             <div className="grid gap-4">
                {selectedMood && suggestions[selectedMood].map((tip, idx) => (
                  <Card key={idx} className="bg-gradient-to-r from-indigo-50 to-white border-l-4 border-l-indigo-400">
                     <CardContent className="p-4 flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-indigo-600 shadow-sm font-bold shrink-0">
                          {idx + 1}
                        </div>
                        <p className="text-gray-800 font-medium">{tip}</p>
                     </CardContent>
                  </Card>
                ))}
             </div>

             <div className="flex justify-center pt-4">
                <Button variant="outline" onClick={() => navigate('/dashboard')}>
                   Back to Dashboard
                </Button>
             </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
