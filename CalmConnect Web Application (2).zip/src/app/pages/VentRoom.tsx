
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getVentPosts, addVentPost, VentPost } from '../services/store';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { MessageCircle, Heart, PenLine, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog'; // Need to create Dialog or use simple modal

// Quick simple modal for this demo since I didn't create Dialog component yet
const SimpleModal = ({ isOpen, onClose, children }: { isOpen: boolean; onClose: () => void; children: React.ReactNode }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-xl relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">✕</button>
        {children}
      </div>
    </div>
  );
};

export const VentRoom = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<VentPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');
  const [sending, setSending] = useState(false);

  const fetchPosts = async () => {
    try {
      const data = await getVentPosts();
      setPosts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
    // Poll for new posts every 30 seconds
    const interval = setInterval(fetchPosts, 30000);
    return () => clearInterval(interval);
  }, []);

  const handlePost = async () => {
    if (!newPostContent.trim() || !user) return;
    setSending(true);
    try {
      await addVentPost(user.id, newPostContent);
      setNewPostContent('');
      setIsModalOpen(false);
      toast.success('Posted anonymously');
      fetchPosts();
    } catch (err) {
      toast.error('Failed to post');
    } finally {
      setSending(false);
    }
  };

  // Mock reaction handling (locally update state only, real app would update DB)
  const handleReaction = (postId: string) => {
    setPosts(posts.map(p => 
      p.id === postId 
        ? { ...p, reactions: { ...p.reactions, heart: (p.reactions?.heart || 0) + 1 } }
        : p
    ));
    toast.success('Sent a hug!');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Anonymous Vent Room</h1>
          <p className="text-gray-500">A safe space to let it out. You are not alone.</p>
        </div>
        <Button onClick={() => setIsModalOpen(true)}>
          <PenLine className="mr-2" size={18} />
          Vent
        </Button>
      </div>

      <div className="grid gap-4">
        {loading ? (
          <p className="text-center text-gray-500 py-10">Loading thoughts...</p>
        ) : posts.length === 0 ? (
          <div className="text-center py-10 bg-white rounded-xl border border-dashed border-gray-300">
            <p className="text-gray-500">The room is quiet. Be the first to share.</p>
          </div>
        ) : (
          posts.map((post) => (
            <Card key={post.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <p className="text-gray-800 text-lg mb-4 whitespace-pre-wrap">{post.content}</p>
                <div className="flex justify-between items-center text-sm text-gray-400">
                  <div className="flex items-center gap-2">
                    <Clock size={14} />
                    <span>{formatDistanceToNow(new Date(post.timestamp))} ago</span>
                  </div>
                  <button 
                    onClick={() => handleReaction(post.id)}
                    className="flex items-center gap-1 text-gray-400 hover:text-pink-500 transition-colors"
                  >
                    <Heart size={18} className={post.reactions?.heart ? "fill-pink-500 text-pink-500" : ""} />
                    <span>{post.reactions?.heart || 0}</span>
                  </button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <SimpleModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <h2 className="text-xl font-bold mb-4">What's on your mind?</h2>
        <p className="text-sm text-gray-500 mb-4">
          This post will be anonymous. Please be kind and supportive.
        </p>
        <textarea
          className="w-full h-32 p-3 border border-gray-200 rounded-lg resize-none focus:ring-2 focus:ring-indigo-500 focus:outline-none mb-4"
          placeholder="I'm feeling..."
          value={newPostContent}
          onChange={(e) => setNewPostContent(e.target.value)}
        />
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={() => setIsModalOpen(false)}>Cancel</Button>
          <Button onClick={handlePost} disabled={!newPostContent.trim() || sending}>
            {sending ? 'Posting...' : 'Post Anonymously'}
          </Button>
        </div>
      </SimpleModal>
    </div>
  );
};
