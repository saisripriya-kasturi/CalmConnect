
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { addTrustedContact, getTrustedContacts, TrustedContact, notifyContact } from '../services/store';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Label } from '../components/ui/label';
import { User, Shield, Bell, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export const Profile = () => {
  const { user } = useAuth();
  const [contacts, setContacts] = useState<TrustedContact[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', email: '', relationship: '' });

  useEffect(() => {
    if (user) {
      getTrustedContacts(user.id).then(setContacts).finally(() => setLoading(false));
    }
  }, [user]);

  const handleAddContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    try {
      const added = await addTrustedContact(user.id, newContact);
      setContacts([...contacts, added]);
      setNewContact({ name: '', email: '', relationship: '' });
      setShowAddForm(false);
      toast.success('Contact added');
    } catch (err) {
      toast.error('Failed to add contact');
    }
  };

  const handleSilentHelp = async () => {
    if (!user) return;
    toast.info('Sending silent alerts...');
    
    // Simulate sending to all contacts
    for (const contact of contacts) {
      await notifyContact(user.id, contact.id);
    }
    
    setTimeout(() => {
      toast.success(`Alert sent to ${contacts.length} contacts.`);
    }, 1500);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold text-gray-900">Your Profile</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 space-y-6">
          <Card>
            <CardContent className="flex flex-col items-center p-8">
              <div className="w-24 h-24 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 mb-4">
                <User size={40} />
              </div>
              <h2 className="text-xl font-semibold">{user?.user_metadata?.name || 'User'}</h2>
              <p className="text-gray-500 text-sm">{user?.email}</p>
            </CardContent>
          </Card>

          <Card className="bg-red-50 border-red-100">
             <CardContent className="p-6">
               <h3 className="text-red-800 font-semibold flex items-center gap-2 mb-2">
                 <Shield size={18} />
                 Emergency
               </h3>
               <p className="text-red-600 text-sm mb-4">
                 If you are in immediate danger, please call emergency services directly.
               </p>
               <Button 
                className="w-full bg-red-600 hover:bg-red-700 text-white" 
                onClick={handleSilentHelp}
                disabled={contacts.length === 0}
               >
                 <Bell size={18} className="mr-2" />
                 Silent Help
               </Button>
               {contacts.length === 0 && (
                 <p className="text-xs text-red-500 mt-2 text-center">Add contacts to enable</p>
               )}
             </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Trusted Contacts</CardTitle>
              <Button size="sm" variant="outline" onClick={() => setShowAddForm(!showAddForm)}>
                <Plus size={16} className="mr-1" />
                Add Contact
              </Button>
            </CardHeader>
            <CardContent>
              {showAddForm && (
                <form onSubmit={handleAddContact} className="bg-gray-50 p-4 rounded-lg mb-6 border border-gray-200">
                   <h4 className="font-medium mb-3">New Contact</h4>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                     <div>
                       <Label>Name</Label>
                       <Input 
                        required
                        value={newContact.name} 
                        onChange={e => setNewContact({...newContact, name: e.target.value})}
                      />
                     </div>
                     <div>
                       <Label>Relationship</Label>
                       <Input 
                        placeholder="e.g. Sister, Best Friend"
                        value={newContact.relationship} 
                        onChange={e => setNewContact({...newContact, relationship: e.target.value})}
                      />
                     </div>
                     <div className="md:col-span-2">
                       <Label>Email</Label>
                       <Input 
                        type="email" 
                        required
                        value={newContact.email} 
                        onChange={e => setNewContact({...newContact, email: e.target.value})}
                      />
                     </div>
                   </div>
                   <div className="flex justify-end gap-2">
                     <Button type="button" variant="ghost" onClick={() => setShowAddForm(false)}>Cancel</Button>
                     <Button type="submit">Save Contact</Button>
                   </div>
                </form>
              )}

              <div className="space-y-3">
                {contacts.length === 0 ? (
                  <p className="text-gray-500 text-center py-6">No trusted contacts added yet.</p>
                ) : (
                  contacts.map(contact => (
                    <div key={contact.id} className="flex items-center justify-between p-4 bg-white border border-gray-100 rounded-lg">
                       <div className="flex items-center gap-3">
                         <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                           <User size={20} />
                         </div>
                         <div>
                           <p className="font-medium text-gray-900">{contact.name}</p>
                           <p className="text-sm text-gray-500">{contact.relationship} • {contact.email}</p>
                         </div>
                       </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
