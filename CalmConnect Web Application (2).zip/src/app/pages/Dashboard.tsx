
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getMoodHistory, MoodEntry } from '../services/store';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { PlusCircle, TrendingUp, Sun, Calendar } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { format, subDays } from 'date-fns';

const moodValues: Record<string, number> = {
  'Happy': 5,
  'Excited': 4,
  'Tired': 3,
  'Anxious': 2,
  'Sad': 1,
  'Angry': 0
};

const getMoodColor = (mood: string) => {
  switch (mood) {
    case 'Happy': return 'text-yellow-500 bg-yellow-50';
    case 'Excited': return 'text-orange-500 bg-orange-50';
    case 'Tired': return 'text-purple-500 bg-purple-50';
    case 'Anxious': return 'text-blue-500 bg-blue-50';
    case 'Sad': return 'text-gray-500 bg-gray-50';
    case 'Angry': return 'text-red-500 bg-red-50';
    default: return 'text-gray-500 bg-gray-50';
  }
};

const quotes = [
  "You don't have to control your thoughts. You just have to stop letting them control you.",
  "Your present circumstances don't determine where you can go; they merely determine where you start.",
  "Breath is the bridge which connects life to consciousness, which unites your body to your thoughts.",
  "Feelings come and go like clouds in a windy sky. Conscious breathing is my anchor.",
];

export const Dashboard = () => {
  const { user } = useAuth();
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      if (user) {
        const history = await getMoodHistory(user.id);
        setMoodHistory(history);
        
        // Prepare chart data (last 7 days)
        const last7Days = Array.from({ length: 7 }, (_, i) => {
          const d = subDays(new Date(), 6 - i);
          return format(d, 'yyyy-MM-dd');
        });

        const data = last7Days.map(dateStr => {
          const entriesOnDate = history.filter(h => h.timestamp.startsWith(dateStr));
          // Average mood for the day if multiple
          let avgMood = 0;
          if (entriesOnDate.length > 0) {
            const sum = entriesOnDate.reduce((acc, curr) => acc + (moodValues[curr.mood] || 0), 0);
            avgMood = sum / entriesOnDate.length;
          }
          return {
            date: format(new Date(dateStr), 'EEE'), // Mon, Tue
            value: entriesOnDate.length > 0 ? avgMood : null
          };
        });
        setChartData(data);
      }
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const recentEntry = moodHistory[0];
  const quote = quotes[Math.floor(Math.random() * quotes.length)];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Hello, {user?.user_metadata?.name || 'Friend'} 👋
          </h1>
          <p className="text-gray-500">How are you feeling today?</p>
        </div>
        <Link to="/check-in">
          <Button className="w-full md:w-auto">
            <PlusCircle className="mr-2" size={20} />
            Check In
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Quote Card */}
        <Card className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white border-none md:col-span-2">
          <CardContent className="flex flex-col justify-center h-full p-8">
            <Sun className="mb-4 opacity-80" size={32} />
            <p className="text-xl md:text-2xl font-medium leading-relaxed opacity-95">
              "{quote}"
            </p>
          </CardContent>
        </Card>

        {/* Recent Mood */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar size={20} className="text-gray-400" />
              Latest Check-in
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentEntry ? (
              <div>
                 <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium mb-3 ${getMoodColor(recentEntry.mood)}`}>
                   {recentEntry.mood}
                 </div>
                 <p className="text-gray-600 italic">"{recentEntry.reflection}"</p>
                 <p className="text-xs text-gray-400 mt-4">
                   {format(new Date(recentEntry.timestamp), 'MMM d, h:mm a')}
                 </p>
              </div>
            ) : (
              <div className="text-center py-6 text-gray-400">
                <p>No check-ins yet.</p>
                <Link to="/check-in" className="text-indigo-600 hover:underline text-sm mt-2 block">Start now</Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Analytics Chart */}
      <Card>
        <CardHeader>
           <CardTitle className="flex items-center gap-2">
              <TrendingUp size={20} className="text-gray-400" />
              Weekly Mood Trends
            </CardTitle>
        </CardHeader>
        <CardContent className="h-64">
           <ResponsiveContainer width="100%" height="100%">
             <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorMood" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} />
                <YAxis hide domain={[0, 5]} />
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  cursor={{ stroke: '#8884d8', strokeWidth: 1 }}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#8884d8" 
                  fillOpacity={1} 
                  fill="url(#colorMood)" 
                  strokeWidth={2}
                  connectNulls
                />
             </AreaChart>
           </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};
