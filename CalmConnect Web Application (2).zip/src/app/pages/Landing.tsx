
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { HeartHandshake, Shield, Smile, Users, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

export const LandingPage = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <HeartHandshake className="text-indigo-600" size={32} />
              <span className="font-bold text-xl text-gray-900">CalmConnect</span>
            </div>
            <div className="flex gap-4">
              <Link to="/login">
                <Button variant="ghost">Log In</Button>
              </Link>
              <Link to="/register">
                <Button>Get Started</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-5xl md:text-6xl font-extrabold tracking-tight text-gray-900 mb-6"
            >
              Your Space for <span className="text-indigo-600">Emotional Balance</span> & Connection
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-xl text-gray-600 mb-10"
            >
              Track your mood, connect safely with others, and find peace in a supportive community. Your emotional well-being matters.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="flex justify-center gap-4"
            >
              <Link to="/register">
                <Button size="lg" className="rounded-full px-8">
                  Start Your Journey <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
        
        {/* Abstract Background Decoration */}
        <div className="absolute top-0 inset-x-0 h-full -z-10 overflow-hidden opacity-30 pointer-events-none">
          <div className="absolute left-[calc(50%-11rem)] top-[calc(50%-30rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]" style={{ clipPath: 'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)' }}></div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white sm:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
            <FeatureCard 
              icon={Smile}
              title="Daily Mood Check-in"
              description="Track your emotional journey with simple, intuitive check-ins. Gain insights into your wellbeing over time."
            />
            <FeatureCard 
              icon={Users}
              title="Anonymous Vent Room"
              description="Share your feelings in a safe, judgment-free space. Receive support from an empathetic community."
            />
            <FeatureCard 
              icon={Shield}
              title="Safe Connections"
              description="Reach out to trusted contacts discreetly when you need support. You are never alone."
            />
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="bg-gray-50 py-12 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 text-center text-gray-500">
          <p>© 2026 CalmConnect. Built with care.</p>
        </div>
      </footer>
    </div>
  );
};

const FeatureCard = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="flex flex-col items-start p-6 bg-slate-50 rounded-2xl border border-slate-100 transition-all hover:shadow-lg hover:-translate-y-1">
    <div className="p-3 bg-indigo-100 text-indigo-600 rounded-xl mb-4">
      <Icon size={32} />
    </div>
    <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
    <p className="text-gray-600 leading-relaxed">{description}</p>
  </div>
);
