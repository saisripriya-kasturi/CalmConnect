
import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { 
  Home, 
  PlusCircle, 
  MessageCircle, 
  User, 
  LogOut, 
  Menu, 
  X,
  HeartHandshake
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from './ui/Button';
import { clsx } from 'clsx';
import { AnimatePresence, motion } from 'framer-motion';

const SidebarLink = ({ to, icon: Icon, children, onClick }: { to: string, icon: any, children: React.ReactNode, onClick?: () => void }) => (
  <NavLink
    to={to}
    onClick={onClick}
    className={({ isActive }) =>
      clsx(
        'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200',
        isActive
          ? 'bg-indigo-50 text-indigo-700 shadow-sm'
          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
      )
    }
  >
    <Icon size={20} />
    {children}
  </NavLink>
);

export const Layout = () => {
  const { signOut, user } = useAuth();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const navItems = [
    { to: '/dashboard', icon: Home, label: 'Dashboard' },
    { to: '/check-in', icon: PlusCircle, label: 'Daily Check-in' },
    { to: '/vent-room', icon: MessageCircle, label: 'Vent Room' },
    { to: '/profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans text-gray-900">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-100 fixed h-full z-10">
        <div className="p-6 border-b border-gray-50 flex items-center gap-2">
          <HeartHandshake className="text-indigo-600" size={32} />
          <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            CalmConnect
          </h1>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => (
            <SidebarLink key={item.to} to={item.to} icon={item.icon}>
              {item.label}
            </SidebarLink>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-50">
          <div className="flex items-center gap-3 px-4 py-3 mb-2">
             <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
               {user?.email?.[0].toUpperCase() || 'U'}
             </div>
             <div className="flex-1 min-w-0">
               <p className="text-sm font-medium text-gray-900 truncate">{user?.user_metadata?.name || user?.email}</p>
             </div>
          </div>
          <Button 
            variant="ghost" 
            className="w-full justify-start text-red-600 hover:bg-red-50 hover:text-red-700"
            onClick={handleSignOut}
          >
            <LogOut size={20} className="mr-3" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md border-b border-gray-100 z-20 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <HeartHandshake className="text-indigo-600" size={28} />
          <span className="font-bold text-lg">CalmConnect</span>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2">
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 top-[57px] bg-white z-10 md:hidden p-4 flex flex-col gap-2"
          >
             {navItems.map((item) => (
                <SidebarLink 
                  key={item.to} 
                  to={item.to} 
                  icon={item.icon} 
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </SidebarLink>
              ))}
              <div className="border-t border-gray-100 my-2 pt-2">
                 <Button 
                  variant="ghost" 
                  className="w-full justify-start text-red-600"
                  onClick={handleSignOut}
                >
                  <LogOut size={20} className="mr-3" />
                  Sign Out
                </Button>
              </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 pt-16 md:pt-0 p-4 md:p-8 overflow-y-auto h-screen scroll-smooth">
        <div className="max-w-5xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
};
