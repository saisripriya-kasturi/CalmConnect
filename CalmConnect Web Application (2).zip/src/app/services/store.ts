import { projectId, publicAnonKey } from '/utils/supabase/info';

const SERVER_URL = `https://${projectId}.supabase.co/functions/v1/make-server-2c9c9f09`;

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`
};

export interface MoodEntry {
  id: string;
  userId: string;
  mood: 'Happy' | 'Sad' | 'Anxious' | 'Angry' | 'Tired' | 'Excited';
  reflection: string;
  timestamp: string;
}

export interface VentPost {
  id: string;
  userId: string;
  content: string;
  reactions: Record<string, number>; // reactionType -> count
  timestamp: string;
  isAnonymous: boolean;
}

export interface TrustedContact {
  id: string;
  name: string;
  email: string;
  relationship: string;
}

// Helper for fetching
const fetchAPI = async (endpoint: string, options: RequestInit = {}) => {
  const response = await fetch(`${SERVER_URL}${endpoint}`, {
    ...options,
    headers: {
      ...headers,
      ...options.headers,
    }
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `API error: ${response.statusText}`);
  }

  return response.json();
};

// Moods
export const addMoodEntry = async (userId: string, entry: Omit<MoodEntry, 'id' | 'userId' | 'timestamp'>) => {
  return fetchAPI('/moods', {
    method: 'POST',
    body: JSON.stringify({ userId, entry }),
  });
};

export const getMoodHistory = async (userId: string): Promise<MoodEntry[]> => {
  return fetchAPI(`/moods/${userId}`);
};

// Vent Posts
export const addVentPost = async (userId: string, content: string, isAnonymous: boolean = true) => {
  return fetchAPI('/vent', {
    method: 'POST',
    body: JSON.stringify({ userId, content, isAnonymous }),
  });
};

export const getVentPosts = async (): Promise<VentPost[]> => {
  return fetchAPI('/vent');
};

// Trusted Contacts
export const addTrustedContact = async (userId: string, contact: Omit<TrustedContact, 'id'>) => {
  return fetchAPI('/contacts', {
    method: 'POST',
    body: JSON.stringify({ userId, contact }),
  });
};

export const getTrustedContacts = async (userId: string): Promise<TrustedContact[]> => {
  return fetchAPI(`/contacts/${userId}`);
};

// Mock "Send Notification" functionality
// In a real app, this would also be a server call to send emails/SMS
export const notifyContact = async (userId: string, contactId: string) => {
  console.log(`Notification sent to contact ${contactId} from user ${userId}`);
  // We can keep this client-side mock for now, or move it to server if needed.
  // Since it was a mock before, we'll keep it simple.
  return true;
};
