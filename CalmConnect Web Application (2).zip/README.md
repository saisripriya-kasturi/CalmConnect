
  # CalmConnect Web Application

  This is a code bundle for CalmConnect Web Application. The original project is available at https://www.figma.com/design/6zuX9abumkQkrDIuipqTYQ/CalmConnect-Web-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  